package com.fasterxml.jackson.core.tree;

import com.fasterxml.jackson.core.TreeNode;

/**
 * Tag interface (for now) for Array nodes
 *
 * @since 3.0
 */
public interface ArrayTreeNode
    extends TreeNode
{

}
